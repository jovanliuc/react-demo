一. 目录结构

    D:\install\PLSQL
        |-- instantclient_11_2
            |-- tnsnames.ora
        |-- PLSQL Developer
        |-- readme.txt

二. 环境变量

    NLS_LANG = SIMPLIFIED CHINESE_CHINA.ZHS16GBK

    TNS_ADMIN = D:\install\PLSQL\instantclient_11_2

三. PL/SQL Developer 环境设置

    1. 位置

        工具 -> 首选项 -> 连接

    2. 设置

        Oracle主目录名  = D:\install\PLSQL\instantclient_11_2

        OCI库 = D:\install\PLSQL\instantclient_11_2\oci.dll 

四. 补充

    tnsnames.ora 文件需要手动创建并进行相应的设置, 参考网上教程.
